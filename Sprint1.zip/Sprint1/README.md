Automated Start up Script for PowerShell. Docker must be running.

1) Run the production_startup.ps1 script to automate the steps below... 
2) in Sqlite3.exe, type in .tables to view the database tables to begin your queries.
3) Navigate to your browser and go to http://localhost:5173/
4) Create an email account it should store it in the database
5) Login with the email account after accepting the email invite URL.
6) Search for another profile and request to chat with them. Chats do not engage until the other member aproves.
7) Chat away.

Or if you prefer/have-to run them manually then follow the steps below.

1) Browse the back end users' database.
    Navigate to .\4900\dotnetc_restful_webapi_user_server\bin\Debug\net8.0\sqlite_users_db
    Run the sqlite3.exe cli program for querying the relational database.
    Type ".open Users.db" and press enter.
    Type ".tables" to see the sqlite's tables.
    Enter queries as needed to view the back end.
2) Start up the back end chat database.
    Start up Docker Software for Windows.
    Navigate to .\4900\redis_websocket_chat_db
    Type in "docker-compose up"
3) Start up back end users' server.
    Navigate to .\4900\dotnetc_restful_webapi_user_server\bin\Debug\net8.0\
    Run the dotnetc_restful_webapi_user_server.exe to launch production in console.
4) Start up the back end mailing server.
    Navigate to .\4900\node_mailer_server
    Run node_mailer_server.js
5) Start up the back end chat server.
    Navigate to .\4900\node_websocket_chat_server
    Run node_websocket_chat_server.js
6) Start up front end graphic user interface application for google chrome.
    Navigate to .\4900\reactbootstrap_spa\ 
    Type in "npm install" to get the node modules and the front end dependencies.
    Type in "npm fund" and press enter.
    Type in "npm audit fix" and press enter.
    Type in "npm run dev" 

    or for Prod.

    npm run build
    npm install -g serve
    serve -s build
    serve -h

7) Create an email account it should store it in the database
8) Login with the email account after accepting the email invite URL.
9) Search for another profile and request to chat with them. Chats do not engage until the other member aproves.
10) Chat away.