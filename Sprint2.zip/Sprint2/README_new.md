# ================================Must have Docker============================================
# All Dev Environments require docker redis image installed from this yaml file
.yaml file used to create this local environment that shown once in Database theory

# Run command in the folder of the .yml file while docker is running on windows. It should create the local database...
docker compose -f docker-compose.yaml up -d

# Start without Yaml cmd
docker run -it {container-id} bash

# Here is the copy of the yaml file from previous database theory course used for local environment dev only
version: '3.8'
services:
  redis:
    image: redis:latest
    container_name: redis_websocket_chat_db
    command: ["redis-server", "/usr/local/etc/redis/redis.conf"]
    ports:
      - 6379:6379
    volumes:
      - redis-data:/data
      - ./redis.conf:/usr/local/etc/redis/redis.conf

volumes:
  redis-data:

# =================== Running Dev/ Accessing Prod ====================================

# Option A -- Automatic for Dev environment windows)
Automated Start up Script for Windows PowerShell for my windows machine. 
Just run the production_startup.ps1 file and should load everything locally (assuming docker is running and yaml file created/executed).
1) Run the production_startup.ps1 script to automate the steps below... 
2) in Sqlite3.exe, type in ".tables" to view the database tables to begin your queries for User Data.

# Option B -- Manually for Dev environment)

1) Browse the back end users' database.
    Navigate to .\4900\dotnetc_restful_webapi_user_server\bin\Debug\net8.0\sqlite_users_db
    Run the sqlite3.exe cli program for querying the relational database.
    Type ".open Users.db" and press enter.
    Type ".tables" to see the sqlite's tables.
    Enter queries as needed to view the back end.
2) Start up the back end chat database.
    Start up Docker Software for Windows.
    Navigate to .\4900\redis_websocket_chat_db
    Type in "docker-compose up"
3) Start up back end users' server.
    Navigate to .\4900\dotnetc_restful_webapi_user_server\bin\Debug\net8.0\
    Run the dotnetc_restful_webapi_user_server.exe to launch production in console.
4) Start up the back end mailing server.
    Navigate to .\4900\node_mailer_server
    Run node_mailer_server.js
5) Start up the back end chat server.
    Navigate to .\4900\node_websocket_chat_server
    Run node_websocket_chat_server.js
6) Start up front end graphic user interface application for google chrome.
    Navigate to .\4900\reactbootstrap_spa\ 
    Type in "npm install" to get the node modules and the front end dependencies.
    Type in "npm fund" and press enter.
    Type in "npm audit fix" and press enter.
    Type in "npm run dev" 

    or for Prod type in

    npm run build
    npm install -g serve
    serve -s build
    serve -h

# Option C -- Hybrid dev-prod Configuration with a dev-client)
    Go to Constants.jsx in the reactbootstrap_spa and adjust the constants as needed as I left my comments in the swithc statement for when would test different tiers using a dev-client.

# ================== Prod URLs ====================
Users Client-Server: http://reactbootstrap-spa.us-east-1.elasticbeanstalk.com/
Users Email Server: http://nodemailerserver.us-east-1.elasticbeanstalk.com/api
Users Primary Server: http://testapp-env.eba-qi4imtyk.us-east-1.elasticbeanstalk.com/api 
Users Chat Server: http://nodewebsocketchatserver.us-east-1.elasticbeanstalk.com/api

# ================== Local URLs ===================


# ================== Unit Tests for projects =======================================================
    
# While in the directory of the project folder -- to run dotnet test on this project use the following command:
dotnet test .\4900\dotnetc_restful_webapi_user_server\dotnetc_restful_webapi_user_server.Tests.csproj

# while in node_mailer, websocket_chat, or reactbootstrap_spa directory you can run test in command prompt after node modules are installed
npx cypress open
npx cypress run 
npx cypress run --browser chrome